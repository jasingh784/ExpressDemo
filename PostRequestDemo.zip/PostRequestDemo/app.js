var express = require("express");
var app = express();
var bodyParser = require("body-parser");

app.use(bodyParser.urlencoded({extended: true}));

app.set("view engine", "ejs");

let friends = ["Tony", "Mirands", "Justin", "Pierre", "Lily"];

app.get("/", (req, res) => {
    res.render("home");
});

app.get("/friends", (req, res) => {
    res.render("friends", {friends: friends});
});

app.post("/addfriend", (req, res) => {
    let newFriend = req.body.newFriend;
    friends.push(newFriend);
    res.redirect("/friends");
});

//Tell express to listen on port 3000
app.listen(3000, () => {
    console.log("The Server is listening!!");
});